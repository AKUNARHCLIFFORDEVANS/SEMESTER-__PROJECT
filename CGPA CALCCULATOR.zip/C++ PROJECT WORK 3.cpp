#include <iostream>
using namespace std;

float calculateGPA(int totalCredits,float totalGradePoints) {return totalGradePoints/totalCredits;
}

int main(){
int totalCredits;
float totalGradePoints;

cout<<"Enter total credits";
cin>>totalCredits;

cout<<"Enter total Grade points";
cin>>totalGradePoints;
	
float gpa = calculateGPA(totalCredits,totalGradePoints);

cout<<"GPA:"<<gpa<<endl;


return 0;
	
}	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

